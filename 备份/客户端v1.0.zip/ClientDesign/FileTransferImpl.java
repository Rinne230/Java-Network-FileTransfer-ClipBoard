import java.io.*;
import java.net.*;

public class FileTransferImpl implements FileTransfer {

    @Override
    public void sendFile(File file, String destinationIp, int port) throws IOException {
        try (Socket socket = new Socket(destinationIp, port);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             FileInputStream fis = new FileInputStream(file);
             BufferedOutputStream bos = new BufferedOutputStream(dos)) {

            dos.writeUTF(file.getName()); // 发送文件名

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            System.err.println("Error while sending file: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void receiveFile(String savePath, int port) throws IOException {
        ServerSocket serverSocket = null;
        while (serverSocket == null) {
            try {
                serverSocket = new ServerSocket(port);
            } catch (BindException e) {
                port++; // 如果端口被占用，尝试下一个端口
            }
        }
        try (Socket socket = serverSocket.accept();
             DataInputStream dis = new DataInputStream(socket.getInputStream());
             BufferedInputStream bis = new BufferedInputStream(dis)) {

            String fileName = dis.readUTF(); // 接收文件名
            File file = new File(savePath, fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = bis.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
            }
        }
    }
}
