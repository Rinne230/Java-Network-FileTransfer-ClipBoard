import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.List;
import java.util.Map;
import java.net.SocketException;

public class FileTransferGUI extends JFrame {

    private FileTransfer fileTransfer = new FileTransferImpl();
    private JComboBox<String> ipComboBox;
    private JButton showUsersButton;
    private Map<String, String> onlineUsers;
    private int registeredPort;
    private String localIP;

    private JTextPane clipboardTextPane;
    private JComboBox<String> languageComboBox;
    private JButton sendClipboardButton;
    private JButton refreshClipboardButton;

    public FileTransferGUI() {
        setTitle("File Transfer and Online Clipboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));

        JPanel filePanel = new JPanel();
        filePanel.setLayout(new GridLayout(5, 1));

        ipComboBox = new JComboBox<>();
        showUsersButton = new JButton("Show Online Users");
        JButton sendButton = new JButton("Send File");
        JButton receiveButton = new JButton("Receive File");

        filePanel.add(new JLabel("Select User:"));
        filePanel.add(ipComboBox);
        filePanel.add(showUsersButton);
        filePanel.add(sendButton);
        filePanel.add(receiveButton);

        add(filePanel);

        JPanel clipboardPanel = new JPanel();
        clipboardPanel.setLayout(new BorderLayout());

        clipboardTextPane = new JTextPane();
        clipboardPanel.add(new JScrollPane(clipboardTextPane), BorderLayout.CENTER);

        JPanel clipboardControlPanel = new JPanel();
        clipboardControlPanel.setLayout(new GridLayout(1, 4));

        languageComboBox = new JComboBox<>(new String[]{"Plain Text", "Java", "Python", "C++"});
        sendClipboardButton = new JButton("Send Clipboard");
        refreshClipboardButton = new JButton("Refresh Clipboard");

        clipboardControlPanel.add(languageComboBox);
        clipboardControlPanel.add(sendClipboardButton);
        clipboardControlPanel.add(refreshClipboardButton);

        clipboardPanel.add(clipboardControlPanel, BorderLayout.SOUTH);

        add(clipboardPanel);

        showUsersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showOnlineUsers();
            }
        });

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    String selectedUser = (String) ipComboBox.getSelectedItem();
                    String destination = getKeyByValue(onlineUsers, selectedUser);
                    String[] ipPort = destination.split(":");
                    String destinationIp = ipPort[0];
                    int port = Integer.parseInt(ipPort[1]);
                    try {
                        System.out.println("Sending file to " + destinationIp + ":" + port);
                        fileTransfer.sendFile(file, destinationIp, port);
                        JOptionPane.showMessageDialog(null, "File Sent Successfully!");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error sending file: " + ex.getMessage());
                    }
                }
            }
        });

        receiveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int result = fileChooser.showSaveDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File directory = fileChooser.getSelectedFile();
                    try {
                        FileReceiveThread receiveThread = new FileReceiveThread(directory.getAbsolutePath(), registeredPort, fileTransfer);
                        receiveThread.start();
                        JOptionPane.showMessageDialog(null, "Receiving File...");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error starting file reception: " + ex.getMessage());
                    }
                }
            }
        });

        sendClipboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String content = clipboardTextPane.getText();
                String language = (String) languageComboBox.getSelectedItem();
                try {
                    ClipboardClient.setClipboardContent(content, language);
                    JOptionPane.showMessageDialog(null, "Clipboard Sent Successfully!");
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error sending clipboard: " + ex.getMessage());
                }
            }
        });

        refreshClipboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshClipboard();
            }
        });

        // 注册客户端到服务器
        registerClient();

        // 添加关闭钩子以取消注册
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                unregisterClient();
            }
        });

        // 初始化剪切板内容
        refreshClipboard();

        // 启动文件接收线程
        startFileReceiveThread();
    }

    private void showOnlineUsers() {
        try {
            onlineUsers = FileTransferClient.getClients();
            ipComboBox.removeAllItems();
            for (String alias : onlineUsers.values()) {
                ipComboBox.addItem(alias);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error getting online users: " + e.getMessage());
        }
    }

    private void registerClient() {
        try {
            localIP = NetworkUtils.getLocalIpAddress(); // 使用 NetworkUtils 获取本地 IP 地址
            String alias = JOptionPane.showInputDialog("Enter your alias:");
            String portString = JOptionPane.showInputDialog("Enter your port number:");
            registeredPort = Integer.parseInt(portString);
            FileTransferClient.register(localIP, registeredPort, alias);
        } catch (SocketException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error determining local IP address: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error registering client: " + e.getMessage());
        }
    }

    private void unregisterClient() {
        try {
            FileTransferClient.unregister(localIP, registeredPort);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void refreshClipboard() {
        try {
            String[] clipboardData = ClipboardClient.getClipboardContent();
            clipboardTextPane.setText(clipboardData[0]);
            languageComboBox.setSelectedItem(clipboardData[1]);
            Highlighter.applyHighlight(clipboardTextPane, clipboardData[1]);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startFileReceiveThread() {
        try {
            FileReceiveThread receiveThread = new FileReceiveThread("C:/temp/", registeredPort, fileTransfer); // 设置一个默认接收目录
            receiveThread.start();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error starting file reception thread: " + e.getMessage());
        }
    }

    private String getKeyByValue(Map<String, String> map, String value) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getValue().equals(value)) {
                return entry.getKey();
            }
        }
        return null;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FileTransferGUI().setVisible(true));
    }
}
