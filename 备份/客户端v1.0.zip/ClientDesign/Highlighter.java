import javax.swing.text.*;
import javax.swing.JTextPane;
import java.awt.*;

public class Highlighter {

    public static void applyHighlight(JTextPane textPane, String language) {
        StyledDocument doc = textPane.getStyledDocument();
        String text = textPane.getText();
        doc.setCharacterAttributes(0, text.length(), textPane.getStyle("default"), true);

        if (language.equals("Java")) {
            highlightJava(textPane, text);
        } else if (language.equals("Python")) {
            highlightPython(textPane, text);
        } else if (language.equals("C++")) {
            highlightCpp(textPane, text);
        }
    }

    private static void highlightJava(JTextPane textPane, String text) {
        StyledDocument doc = textPane.getStyledDocument();
        Style keywordStyle = textPane.addStyle("Keyword", null);
        StyleConstants.setForeground(keywordStyle, Color.BLUE);
        String[] keywords = {"abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", 
                             "const", "continue", "default", "do", "double", "else", "enum", "extends", "final", 
                             "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", 
                             "interface", "long", "native", "new", "package", "private", "protected", "public", 
                             "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this", 
                             "throw", "throws", "transient", "try", "void", "volatile", "while"};

        for (String keyword : keywords) {
            int lastIndex = 0;
            while ((lastIndex = text.indexOf(keyword, lastIndex)) != -1) {
                doc.setCharacterAttributes(lastIndex, keyword.length(), keywordStyle, true);
                lastIndex += keyword.length();
            }
        }
    }

    private static void highlightPython(JTextPane textPane, String text) {
        StyledDocument doc = textPane.getStyledDocument();
        Style keywordStyle = textPane.addStyle("Keyword", null);
        StyleConstants.setForeground(keywordStyle, Color.BLUE);
        String[] keywords = {"False", "class", "finally", "is", "return", "None", "continue", "for", "lambda", 
                             "try", "True", "def", "from", "nonlocal", "while", "and", "del", "global", "not", 
                             "with", "as", "elif", "if", "or", "yield", "assert", "else", "import", "pass", 
                             "break", "except", "in", "raise"};

        for (String keyword : keywords) {
            int lastIndex = 0;
            while ((lastIndex = text.indexOf(keyword, lastIndex)) != -1) {
                doc.setCharacterAttributes(lastIndex, keyword.length(), keywordStyle, true);
                lastIndex += keyword.length();
            }
        }
    }

    private static void highlightCpp(JTextPane textPane, String text) {
        StyledDocument doc = textPane.getStyledDocument();
        Style keywordStyle = textPane.addStyle("Keyword", null);
        StyleConstants.setForeground(keywordStyle, Color.BLUE);
        String[] keywords = {"alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel", "atomic_commit", 
                             "atomic_noexcept", "auto", "bitand", "bitor", "bool", "break", "case", "catch", "char", 
                             "char8_t", "char16_t", "char32_t", "class", "compl", "concept", "const", "consteval", 
                             "constexpr", "constinit", "const_cast", "continue", "co_await", "co_return", 
                             "co_yield", "decltype", "default", "delete", "do", "double", "dynamic_cast", "else", 
                             "enum", "explicit", "export", "extern", "false", "float", "for", "friend", "goto", 
                             "if", "inline", "int", "long", "mutable", "namespace", "new", "noexcept", "not", 
                             "not_eq", "nullptr", "operator", "or", "or_eq", "private", "protected", "public", 
                             "reflexpr", "register", "reinterpret_cast", "requires", "return", "short", "signed", 
                             "sizeof", "static", "static_assert", "static_cast", "struct", "switch", "synchronized", 
                             "template", "this", "thread_local", "throw", "true", "try", "typedef", "typeid", 
                             "typename", "union", "unsigned", "using", "virtual", "void", "volatile", "wchar_t", 
                             "while", "xor", "xor_eq"};

        for (String keyword : keywords) {
            int lastIndex = 0;
            while ((lastIndex = text.indexOf(keyword, lastIndex)) != -1) {
                doc.setCharacterAttributes(lastIndex, keyword.length(), keywordStyle, true);
                lastIndex += keyword.length();
            }
        }
    }
}
