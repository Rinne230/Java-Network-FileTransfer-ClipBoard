import java.io.IOException;

public class FileReceiveThread extends Thread {
    private final String savePath;
    private final int port;
    private final FileTransfer fileTransfer;

    public FileReceiveThread(String savePath, int port, FileTransfer fileTransfer) {
        this.savePath = savePath;
        this.port = port;
        this.fileTransfer = fileTransfer;
    }

    @Override
    public void run() {
        try {
            fileTransfer.receiveFile(savePath, port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
