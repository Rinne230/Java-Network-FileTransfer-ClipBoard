import java.io.File;
import java.io.IOException;

public interface FileTransfer {
    void sendFile(File file, String destinationIp, int port) throws IOException;
    void receiveFile(String savePath, int port) throws IOException;
}
