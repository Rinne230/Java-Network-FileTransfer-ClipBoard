import java.io.*;
import java.net.*;
import java.util.*;

public class FileTransferClient {
    private static final String SERVER_IP = "172.20.10.2";  // 替换为实际的服务器IP地址
    private static final int SERVER_PORT = 8888;

    public static void register(String localIp, int port, String alias) throws IOException {
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            dos.writeUTF("REGISTER");
            dos.writeUTF(localIp);
            dos.writeUTF(Integer.toString(port));
            dos.writeUTF(alias);

            String response = dis.readUTF();
            if (!response.equals("REGISTERED")) {
                throw new IOException("Failed to register with server");
            }
        }
    }

    public static void unregister(String localIp, int port) throws IOException {
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            dos.writeUTF("UNREGISTER");
            dos.writeUTF(localIp);
            dos.writeUTF(Integer.toString(port));

            String response = dis.readUTF();
            if (!response.equals("UNREGISTERED")) {
                throw new IOException("Failed to unregister with server");
            }
        }
    }

    public static Map<String, String> getClients() throws IOException {
        Map<String, String> clients = new LinkedHashMap<>();
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            dos.writeUTF("GET_CLIENTS");

            int size = dis.readInt();
            for (int i = 0; i < size; i++) {
                String[] clientInfo = dis.readUTF().split(",");
                clients.put(clientInfo[0], clientInfo[1]); // Key: IP:Port, Value: Alias
            }
        }
        return clients;
    }
}
