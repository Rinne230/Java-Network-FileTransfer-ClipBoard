import java.io.*;
import java.net.*;
import java.util.*;

public class CentralServer {
    private static final int PORT = 8888;
    private static Map<String, String> clients = Collections.synchronizedMap(new HashMap<>());

    public static void main(String[] args) {
        System.out.println("Central Server is running...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (DataInputStream dis = new DataInputStream(socket.getInputStream());
                 DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

                String command = dis.readUTF();
                if (command.equals("REGISTER")) {
                    String ip = dis.readUTF();
                    String port = dis.readUTF();
                    String alias = dis.readUTF();
                    String id = ip + ":" + port;
                    clients.put(id, alias);
                    dos.writeUTF("REGISTERED");
                } else if (command.equals("UNREGISTER")) {
                    String ip = dis.readUTF();
                    String port = dis.readUTF();
                    String id = ip + ":" + port;
                    clients.remove(id);
                    dos.writeUTF("UNREGISTERED");
                } else if (command.equals("GET_CLIENTS")) {
                    dos.writeInt(clients.size());
                    for (Map.Entry<String, String> entry : clients.entrySet()) {
                        dos.writeUTF(entry.getKey() + "," + entry.getValue());
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
