import java.io.*;
import java.net.*;
import java.util.*;

public class ClipboardServer {
    private static final int PORT = 8889;
    private static String clipboardContent = "";
    private static String language = "Plain Text";

    public static void main(String[] args) {
        System.out.println("Clipboard Server is running...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (DataInputStream dis = new DataInputStream(socket.getInputStream());
                 DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

                String command = dis.readUTF();
                if (command.equals("SET_CLIPBOARD")) {
                    clipboardContent = dis.readUTF();
                    language = dis.readUTF();
                } else if (command.equals("GET_CLIPBOARD")) {
                    dos.writeUTF(clipboardContent);
                    dos.writeUTF(language);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
